/*
  TinySoftwareSerial.cpp - Hardware serial library for Wiring
  Copyright (c) 2006 Nicholas Zambetti.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  Modified 23 November 2006 by David A. Mellis
  Modified 28 September 2010 by Mark Sproul
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <avr/io.h> 

#include "Arduino.h"
#include "wiring_private.h"

#if USE_SOFTWARE_SERIAL 
#include "TinySoftwareSerial.h"

// Define constants and variables for buffering incoming serial data.  We're
// using a ring buffer (I think), in which rx_buffer_head is the index of the
// location to which to write the next incoming character and rx_buffer_tail
// is the index of the location from which to read.

extern "C"{
uint8_t getch() {
    uint8_t ch = 0;
    __asm__ __volatile__ (
		"   rcall uartDelay\n"          // Get to 0.25 of start bit (our baud is too fast, so give room to correct)
		"1: rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   clc\n"
		"   in r23,%[pin]\n"
		"   and r23, %[mask]\n"
		"   breq 2f\n"
		"   sec\n"
		"2: ror   %0\n"                    
		"   dec   %[count]\n"
		"   breq  3f\n"
		"   rjmp  1b\n"
		"3: rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		:
		  "=r" (ch)
		:
		  "0" ((uint8_t)0),
		  [count] "r" ((uint8_t)8),
		  [pin] "I" (_SFR_IO_ADDR(SOFTWARE_SERIAL_PIN)),
		  [mask] "r" (Serial._rxmask)
		:
		  "r23",
		  "r24",
		  "r25"
    );
	return ch;
}

void uartDelay() {
  __asm__ __volatile__ (
    "mov r25,%[count]\n"
    "1:dec r25\n"
    "brne 1b\n"
    "ret\n"
	::[count] "r" ((uint8_t)Serial._delayCount)
  );
}

#if !defined (PCINT0_vect) && defined(PCINT_vect)
	#define PCINT0_vect PCINT_vect
#elif !defined (PCINT0_vect)
	#error Cant find pin change interrupt vector!
#endif
ISR(PCINT0_vect){
    digitalWrite(3,HIGH);
	uint8_t check = SOFTWARE_SERIAL_PIN & Serial._rxmask;
	if(check){
		return; //bit has just gone high. Not interested as it cannot be a start bit.
	}
	uint8_t ch = getch();
    store_char(ch, Serial._rx_buffer);
}
#if defined(PCINT1_vect)
ISR(PCINT1_vect, ISR_ALIASOF(PCINT0_vect)); //point both PCInterrupts to the same place.
#endif

}
soft_ring_buffer rx_buffer  =  { { 0 }, 0, 0 };

// Constructor ////////////////////////////////////////////////////////////////

TinySoftwareSerial::TinySoftwareSerial(soft_ring_buffer *rx_buffer, volatile uint8_t *pcifr, uint8_t txPin, uint8_t rxPin)
{
    _rx_buffer = rx_buffer;
    
    _pcmsk = digitalPinToPCMSK(rxPin);
    _pcicr = digitalPinToPCICR(rxPin);
    _pcifr = pcifr;
	
	pinMode(txPin,OUTPUT);
	digitalWrite(txPin,HIGH);
	pinMode(rxPin,INPUT);	
	
    _rxmask = digitalPinToBitMask(rxPin);
    _txmask = digitalPinToBitMask(txPin);
	_txunmask = ~_txmask;
	
    _pcie = digitalPinToPCICRbit(rxPin);
	#if defined(PCIF1)
    _pcif = (_pcie == PCIE0) ? PCIF0 : PCIF1;
	#else
    _pcif = PCIF;
	#endif
    _pcint = digitalPinToPCMSKbit(rxPin);
	
	
	_delayCount = 0;	
}

// Public Methods //////////////////////////////////////////////////////////////

void TinySoftwareSerial::begin(long baud)
{
  long tempDelay = (((F_CPU/baud)-39)/12);
  if (tempDelay > 255){
	end(); //Cannot start as there would be an error.
  }
  _delayCount = (uint8_t)tempDelay;
  sbi(*_pcicr,_pcie);
  sbi(*_pcmsk,_pcint);
}

void TinySoftwareSerial::end()
{
  cbi(*_pcicr,_pcie); //disable the interrupt
  cbi(*_pcmsk,_pcint);  //remove the RX pin from the mask
  _delayCount = 0;
  _rx_buffer->head = _rx_buffer->tail;
}

int TinySoftwareSerial::available(void)
{
  return (unsigned int)(SERIAL_BUFFER_SIZE + _rx_buffer->head - _rx_buffer->tail) % SERIAL_BUFFER_SIZE;
}

void store_char(unsigned char c, soft_ring_buffer *buffer)
{
  int i = (unsigned int)(buffer->head + 1) % SERIAL_BUFFER_SIZE;

  // if we should be storing the received character into the location
  // just before the tail (meaning that the head would advance to the
  // current location of the tail), we're about to overflow the buffer
  // and so we don't write the character or advance the head.
  if (i != buffer->tail) {
    buffer->buffer[buffer->head] = c;
    buffer->head = i;
  }
}

int TinySoftwareSerial::peek(void)
{
  if (_rx_buffer->head == _rx_buffer->tail) {
    return -1;
  } else {
    return _rx_buffer->buffer[_rx_buffer->tail];
  }
}

int TinySoftwareSerial::read(void)
{
  // if the head isn't ahead of the tail, we don't have any characters
  if (_rx_buffer->head == _rx_buffer->tail) {
    return -1;
  } else {
    unsigned char c = _rx_buffer->buffer[_rx_buffer->tail];
    _rx_buffer->tail = (unsigned int)(_rx_buffer->tail + 1) % SERIAL_BUFFER_SIZE;
    return c;
  }
}

size_t TinySoftwareSerial::write(uint8_t ch)
{
  //putch(ch);
  cli(); //Prevent interrupts from breaking the transmission. Note: TinySoftwareSerial is half duplex.
  //it can either recieve or send, not both (because recieving requires an interrupt and would stall transmission
  __asm__ __volatile__ (
    "   com %[ch]\n" // ones complement, carry set
    "   sec\n"
    "1: brcc 2f\n"
	"   in r23,%[uartPort] \n"
    "   and r23,%[uartUnmask]\n"
	"   out %[uartPort],r23 \n"
    "   rjmp 3f\n"
	"2: in r23,%[uartPort] \n"
    "   or r23,%[uartMask]\n"
	"   out %[uartPort],r23 \n"
    "   nop\n"
    "3: rcall uartDelay\n"
    "   rcall uartDelay\n"
    "   rcall uartDelay\n"
    "   rcall uartDelay\n"
    "   lsr %[ch]\n"
    "   dec %[count]\n"
    "   brne 1b\n"
    :
    :
      [ch] "r" (ch),
	  [count] "r" ((uint8_t)10),
      [uartPort] "I" (_SFR_IO_ADDR(SOFTWARE_SERIAL_PORT)),
      [uartMask] "r" (_txmask),
      [uartUnmask] "r" (_txunmask)
	: "r23",
	  "r24",
	  "r25"
  );
  sei();
  return 1;
}
/*
    __asm__ __volatile__ (
		"   rcall uartDelay\n"          // Get to 0.25 of start bit (our baud is too fast, so give room to correct)
		"1: rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   clc\n"
		"   in r23,%[pin]\n"
		"   and r23, %[mask]\n"
		"   breq 2f\n"
		"   sec\n"
		"2: ror   %0\n"                    
		"   dec   %[count]\n"
		"   breq  3f\n"
		"   rjmp  1b\n"
		"3: rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		"   rcall uartDelay\n"              // Wait 0.25 bit period
		:
		  "=r" (ch)
		:
		  "0" ((uint8_t)0),
		  [count] "r" ((uint8_t)8),
		  [pin] "I" (_SFR_IO_ADDR(SOFTWARE_SERIAL_PIN)),
		  [mask] "r" (Serial._rxmask)
		:
		  "r23",
		  "r24",
		  "r25"
    );
*/
void TinySoftwareSerial::flush()
{
  
}

TinySoftwareSerial::operator bool() {
	return true;
}

// Preinstantiate Objects //////////////////////////////////////////////////////

#ifndef SOFTWARE_SERIAL_TX
#error Please define the software serial TX pin in pins_arduino.h
#endif
#ifndef SOFTWARE_SERIAL_RX
#error Please define the software serial RX pin in pins_arduino.h
#endif

#if defined(EIFR)
    TinySoftwareSerial Serial(&rx_buffer, &EIFR, SOFTWARE_SERIAL_TX, SOFTWARE_SERIAL_RX);
#elif defined(GIFR)
    TinySoftwareSerial Serial(&rx_buffer, &GIFR, SOFTWARE_SERIAL_TX, SOFTWARE_SERIAL_RX);
#else
#error Interrupt Flag Register not found. Please define at bottom of TinySoftwareSerial.cpp
#endif

#endif // whole file
